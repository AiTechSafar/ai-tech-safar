---
name: Tool request
about: Suggest a useful tool for AI Tech Safar
labels: enhancement
---

## Problem to solve

## Who would use this?

## Proposed tool or feature

## Example use case

## Additional references (optional)
